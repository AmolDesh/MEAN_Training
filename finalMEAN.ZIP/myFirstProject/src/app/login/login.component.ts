import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'; // Import Router
import { TalkWithServerService } from '../talk-with-server.service'; // Import the service

@Component({
  selector: 'app-login',
  standalone:false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private talkWithServer: TalkWithServerService) {

    // Initialize the form
    this.loginForm = this.fb.group({
      emailId: ['', [Validators.required, Validators.email]], // Changed to emailId to match the backend
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {}

  // Method to handle form submission
  onSubmit(): void {
    if (this.loginForm.valid) {
      console.log('Form Submitted!', this.loginForm.value);
      // Send login data to the server for validation
      this.talkWithServer.loginUser(this.loginForm.value).subscribe({
        next: (response: any) => {
          if (response && response.status) {
            console.log('Login successful', response);
            this.router.navigate(['/products']); // Navigate to the products page after successful login
          } else {
            console.error('Login failed');
          }
        },
        error: (error) => {
          console.error('Login error', error);
        }
      });
    } else {
      console.log('Form is invalid');
    }
  }
}