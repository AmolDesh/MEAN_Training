import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Products } from './model/Products';
import { catchError, map, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TalkWithServerService {
  private serverUrl = "http://localhost:3000/products"; // Define serverUrl as a class property
  private userUrl = "http://localhost:3000/users"; // Define user API URL

  constructor(private httpClient: HttpClient) {}

  getProductsArr(): Observable<Products[]> {
    return this.httpClient.get<{ data: Products[], status: string }>(this.serverUrl).pipe(
      map(response => response['data']),
      catchError(err => {
        console.error('Error fetching products:', err);
        return of([]); // Return an empty array in case of error
      })
    );
  }
  // New method for user registration
  registerUser(userObj: { emailId: string; password: string }): Observable<any> {
    return this.httpClient.post(`${this.userUrl}/register`, userObj).pipe(
      catchError(err => {
        console.error('Error registering user:', err);
        return of(null); // Return null in case of error
      })
    );
  }

  // New method for user login
  loginUser(userObj: { emailId: string; password: string }): Observable<any> {
    return this.httpClient.post(`${this.userUrl}/login`, userObj).pipe(
      catchError(err => {
        console.error('Error logging in user:', err);
        return of(null); // Return null in case of error
      })
    );
  }

  getParticularProduct(productId: number): Observable<Products | null> {
    return this.httpClient.get<{ data: Products, status: string }>(`${this.serverUrl}/${productId}`).pipe(
      map(response => response.data),
      catchError(err => {
        console.error(`Error fetching product with ID ${productId}:`, err);
        return of(null); // Return null in case of error
      })
    );
  }

  getAllProductsItems(): Observable<Products[]> {
    return this.httpClient.get<{ data: Products[], status: string }>(this.serverUrl).pipe(
      map(response => response['data']),
      catchError(err => {
        console.error('Error fetching all products:', err);
        return of([]); // Return an empty array in case of error
      })
    );
  }

  addProduct(productsObj: Products): Observable<Products | null> {
    return this.httpClient.post<Products>(this.serverUrl, productsObj).pipe(
      catchError(err => {
        console.error('Error adding product:', err);
        return of(null); // Return null in case of error
      })
    );
  }

  deleteProduct(productId: number): Observable<boolean> {
    return this.httpClient.delete(`${this.serverUrl}/${productId}`).pipe(
      map(response => {
        // Assuming the server returns a success message or status
        return true; // Return true if deletion was successful
      }),
      catchError(err => {
        console.error('Error deleting product:', err);
        return of(false); // Return false if there was an error
      })
    );
  }
  updateProduct(product: Products): Observable<Products | null> {
    return this.httpClient.put<Products>(`${this.serverUrl}/${product.productId}`, product).pipe(
        catchError(err => {
            console.error('Error updating product:', err);
            return of(null); // Return null in case of error
        })
    );
  }
}
