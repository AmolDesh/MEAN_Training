import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductManagementService } from '../product-management.service';
import { Products } from '../model/Products';

@Component({
  selector: 'app-product-details',
  standalone: false,
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  selectedProductId: number;
  selectedProduct: Products | null;

  constructor(private route: ActivatedRoute, private productManagementService: ProductManagementService) {
    this.selectedProductId = -1;
    this.selectedProduct = null;
  }

  ngOnInit() {
    if (this.route.snapshot.paramMap.has("productId")) {
      this.selectedProductId = parseInt(this.route.snapshot.paramMap.get("productId") ?? "-1");
      this.productManagementService.getproductInfo(this.selectedProductId)
        .subscribe({
          next: (response) => {
            console.log("Response from the fetch request to /products", response);
            this.selectedProduct=response;
          },
          error: (err) => {
            console.log(err);
            this.selectedProduct=null;
          }

        })

    }
    else {
      this.selectedProductId = -1;
    }

}
}
