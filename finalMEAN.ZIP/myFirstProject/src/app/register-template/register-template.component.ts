import { Component, OnInit } from '@angular/core';
import { Form, FormControl, FormGroup, Validators } from '@angular/forms';
import { TalkWithServerService } from '../talk-with-server.service'; // Import the service
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-register-template',
  standalone: false,
  templateUrl: './register-template.component.html',
  styleUrl: './register-template.component.css'
})
export class RegisterTemplateComponent {
  registerForm: FormGroup;

  constructor(private talkWithServer: TalkWithServerService, private router: Router) {
    this.registerForm = new FormGroup({
      emailId: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)])
    });
  }
  ngOnInit(): void {}
/*   submitEventHandler(registerFormValues: any): void {
    if (this.registerForm.valid) {
      console.log(registerFormValues);
      // Send this data to the server via POST request
      this.talkWithServer.registerUser(registerFormValues).subscribe({
        next: (response) => {
          if (response) {
            console.log('Registration successful', response);
            this.router.navigate(['/login']); // Navigate to login page after successful registration
          } else {
            console.error('Registration failed');
          }
        },
        error: (error) => {
          console.error('Registration error', error);
        }
      });
    } else {
      console.log('Form is invalid');
    }
  }
} */
  onSubmit(): void {
    if (this.registerForm.valid) {
      console.log('Registration Form Submitted!', this.registerForm.value);
      this.talkWithServer.registerUser(this.registerForm.value).subscribe({
        next: (response: any) => {
          if (response && response.status) {
            console.log('Registration successful', response);
            this.router.navigate(['/login']); // Navigate to login page after successful registration
          } else {
            console.error('Registration failed');
          }
        },
        error: (error) => {
          console.error('Registration error', error);
        }
      });
    } else {
      console.log('Registration form is invalid');
    }
  }
}