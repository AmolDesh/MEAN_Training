import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // Import FormsModule 
//import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CartComponent } from './cart/cart.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { SearchArrPipe } from './search-arr.pipe';
import { BgColorDirective } from './bg-color.directive';
import { EditProductComponent } from './edit-product/edit-product.component';
import { TwoWayDataBindingExamplesComponent } from './two-way-data-binding-examples/two-way-data-binding-examples.component';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { RegisterTemplateComponent } from './register-template/register-template.component';
import { RegisterModelComponent } from './register-model/register-model.component';
import { CheckPasswordPatternDirective } from './check-password-pattern.directive';
import { MainHomeComponent } from './main-home/main-home.component';
import { MenuComponent } from './menu/menu.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByUPIComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { CartManagementService } from './cart-management.service';
import { ProductManagementService } from './product-management.service';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    HomeComponent,
    ProductDisplayComponent,
    AddToCartComponent,
    CartComponent,
    SearchArrPipe,
    SearchProductsComponent,
    BgColorDirective,
    DirectiveExamplesComponent,
    EditProductComponent,
    TwoWayDataBindingExamplesComponent,
    RegisterTemplateComponent,
    RegisterModelComponent,
    CheckPasswordPatternDirective,
    MainHomeComponent,
    MenuComponent,
    PageNotFoundComponent,
    PaymentsComponent,
    PaymentByCardComponent,
    PaymentByUPIComponent,
    PaymentByWalletComponent,
    PaymentByNetBankingComponent,
    ProductDetailsComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    //AppRoutingModule,
    FormsModule,
    //RegisterModelComponent,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
],
providers: [CartManagementService, ProductManagementService],
bootstrap: [AppComponent]
})
export class AppModule { }
 