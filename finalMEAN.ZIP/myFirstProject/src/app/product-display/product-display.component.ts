/* import { Component } from '@angular/core';
//import {Products} from ProductDisplayComponent;

export interface Products { // Define the Product interface here
  id: number;
  name: string;
  image: string;
  description: string;
  price: number;
  availableQuantity: number; // Add this property to track available quantity
  //quantity:number;
}

@Component({
  selector: 'app-product-display',
  standalone: false,
  templateUrl: './product-display.component.html',
  styleUrl: './product-display.component.css'
})
export class ProductDisplayComponent {
  companyName:string;
  //showAddToCart:boolean;
  selectedProduct:Products|null;
  productsArr = [
    {
      id: 1,
      name: 'Product 1',
      image: 'Prd1.png', // Placeholder image
      description: 'This is a short description of Product 1.',
      price: 29.99,
      availableQuantity: 10
      //quantity: 1
    },
    {
      id: 2,
      name: 'Product 2',
      image: 'Prd2.jpg', // Placeholder image
      description: 'This is a short description of Product 2.',
      price: 49.99,
      availableQuantity: 15
      //quantity: 1
    },
    {
      id: 3,
      name: 'Product 3',
      image: 'Prd3.jpg', // Placeholder image
      description: 'This is a short description of Product 3.',
      price: 19.99,
      availableQuantity: 12
      //quantity: 1
    },
    {
      id: 4,
      name: 'Product 4',
      image: 'Prd4.png', // Placeholder image
      description: 'This is a short description of Product 4.',
      price: 39.99,
      availableQuantity: 5
      //quantity: 1
    },
    {
      id: 5,
      name: 'Product 5',
      image: 'Prd5.jpg', // Placeholder image
      description: 'This is a short description of Product 5.',
      price: 59.99,
      availableQuantity: 25
      //quantity: 1
    }
  ];

  constructor() {
    // You can perform any initialization here if needed
    this.companyName="Marsh";
    //this.showAddToCart=false;
    this.selectedProduct=null;
   }
  onSelectProduct(product: Products) {
      this.selectedProduct = product; // Set the selected product
      //this.selectedProduct.quantity = 1; // Reset quantity to 1 for the new product
  }

/*   addToCart(product: Products) {
      if (this.quantity > 0 && this.quantity <= product.availableQuantity) {
        alert(`Added ${this.quantity} of ${product.name} to cart!`);
          // Implement logic to add the product to the cart
      } else {
        alert(`Please select a quantity between 1 and ${product.availableQuantity}.`);
      }
  }

  incrementQuantity() {
      if (this.selectedProduct && this.quantity < this.selectedProduct.availableQuantity) {
          this.quantity++;
      } else {
          alert(`Cannot select more than available quantity (${this.selectedProduct?.availableQuantity}).`);
      }
  }

  decrementQuantity() {
      if (this.quantity > 1) {
          this.quantity--;
      } else {
          alert('Quantity cannot be less than 1.');
      }
  }
 } 
 */
 import { Component, inject, OnInit } from '@angular/core';
 import { Products } from '../model/Products';
 import { Cart } from '../model/Cart';
 import { Router } from '@angular/router';
 import { ProductManagementService } from '../product-management.service';
 
  
 @Component({
   selector: 'app-product-display',
   standalone: false,
   templateUrl: './product-display.component.html',
   styleUrls: ['./product-display.component.css']
 })
 export class ProductDisplayComponent implements OnInit{
  productsArr: Products[];
  companyName: string;
  showAddToCart: boolean;
  selectedProduct: Products | null;
  productManagementService: ProductManagementService;
  constructor(private router: Router) {
    this.productManagementService = inject(ProductManagementService)
    this.selectedProduct = null;
    this.companyName = "Marsh";
    this.showAddToCart = false;
    this.productsArr = [];
  }
  ngOnInit(): void {
    this.productManagementService.getAllProductsItems()
      .subscribe({
        next: (response) => {
          console.log("Response from the fet request to /products", response);
          this.productsArr = response;
        },
        error: (err) => {
          console.log(err);
          this.productsArr = [];
        }
      })

  }
  addToCart(selectedProduct: Products) {
    alert("Button clicked" + selectedProduct.productName);
    this.showAddToCart = true;
    this.selectedProduct = selectedProduct;
  }
  changeCompanyName() {
    this.companyName = "Apple";
  }
  sendDataFromAddToCartToPDEventHandler(cartObj: Cart | null) {
    if (cartObj != null) {
      // update the quantity in productsArr
      var pos = this.productsArr.findIndex(product => product.productId == cartObj.productId);
      if (pos >= 0) {
        this.productsArr[pos].quantity = this.productsArr[pos].quantity - cartObj.quantitySelected;
      }

      // unmount the child component
      this.showAddToCart = false;
      // selectedProduct -- null
      this.selectedProduct = null;
    }
  }
  sendCancelEventFromAddToCartToPDEventHandler() {
    this.showAddToCart = false;
    this.selectedProduct = null;
  }
  detailsEventHandler(selectedProduct: Products) {
    // navigate to productdetails component
    this.router.navigate(["productDetails", selectedProduct.productId]);//productDetails/101

  }

 }