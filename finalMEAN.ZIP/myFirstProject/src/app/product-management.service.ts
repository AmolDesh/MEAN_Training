import { Injectable } from '@angular/core';
import { Products } from './model/Products';
import { Observable } from 'rxjs';
import { TalkWithServerService } from './talk-with-server.service';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor(private talkWithServer: TalkWithServerService) { 
/*     this.productsArr = [
      new Products(101, "Product 1", "Prd1.png", "Product 1 Description", 112345, 5),
      new Products(102, "Product 2", "Prd2.jpg", "Product 2 Description", 11345, 10),
      new Products(103, "Product 3", "Prd3.jpg", "Product 3 Description", 56782, 15),
      new Products(104, "Product 4", "Prd4.png", "Product 4 Description", 151345, 20),
      new Products(105, "Product 5", "Prd5.jpg", "Product 5 Description", 12345, 25),
    ]; */
    this.productsArr = [];;
  }
/*   addProductsItem(ProductsObj: Products) {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr)
  } */
  addProductsItem(productsObj: Products): Observable<Products | null> {
      // Call the TalkWithServerService to add the product to the server
      return this.talkWithServer.addProduct(productsObj);
    }
  getAllProductsItems(): Observable<Products[]> {
    // return this.productsArr;
    return this.talkWithServer.getProductsArr();

  }
  /* deleteProductsItem(productId: number) {
    var pos = this.productsArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.productsArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  } */
  deleteProductsItem(productId: number): Observable<boolean> {
      // Call the TalkWithServerService to delete the product from the server
      return this.talkWithServer.deleteProduct(productId);
    }
  getproductInfo(productId: number): Observable<Products | null> {
    return this.talkWithServer.getParticularProduct(productId);

  }
  updateProductQuantity(product: Products): Observable<Products | null> {
    return this.talkWithServer.updateProduct(product);
  }
}
