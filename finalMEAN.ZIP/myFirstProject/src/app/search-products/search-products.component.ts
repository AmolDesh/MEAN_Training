import { Component, OnInit } from '@angular/core';
import { Products } from '../model/Products';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-search-products',
  standalone: false,
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
  productsArr: Products[]= [];
  searchText: string;
  fieldName: string;
  fieldNameArr: string[];
  selectedProduct: Products | null;
  constructor(private productManagementService: ProductManagementService) {
    this.selectedProduct = null;
    this.fieldName = "";
    this.searchText = "";
    this.fieldNameArr = ["productName", "price", "quantity"];
  }
  ngOnInit(): void {
    this.productManagementService.getAllProductsItems().subscribe(
      (products: Products[]) => {
        this.productsArr = products; // Assign the received products to the array
      },
      (error) => {
        console.error('Error fetching products:', error); // Handle error
      }
    );
  }
  searchEventHandler(text: string, fieldName: string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }
  editEventHandler(selectedProduct: Products) {
    this.selectedProduct = selectedProduct;
  }
}
