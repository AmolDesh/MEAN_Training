// requires
var express = require('express');
var path = require("path");
var cors = require("cors");
var userController = require("./controller/userController"); // Ensure this is uncommented to use userController
var productsRouter = require("./routes/productRouter");
var usersRouter = require("./routes/userRouter");

// initialisations
var PORT = 3000;
var app = express();
var empArr = [
    { empId: 101, empName: "Asha", salary: 1001, deptId: "D1" },
    { empId: 102, empName: "Gaurav", salary: 2000, deptId: "D1" },
    { empId: 103, empName: "Karan", salary: 2000, deptId: "D2" },
    { empId: 104, empName: "Kishan", salary: 3000, deptId: "D1" },
    { empId: 105, empName: "Keshav", salary: 3500, deptId: "D2" },
    { empId: 106, empName: "Pran", salary: 4000, deptId: "D3" },
    { empId: 107, empName: "Saurav", salary: 3800, deptId: "D3" }
];

var corsOptions = {
    origin: "http://localhost:4200",
};

// middlewares
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors(corsOptions));

// routes
app.use("/products", productsRouter);
app.use("/users", usersRouter);

// Serve the index.html file
app.get("/", (request, response) => {
    var filePath = path.join(__dirname, "public", "index.html");
    response.sendFile(filePath); // default status code -- 200
});

// Serve employees data
app.get("/employees", (request, response) => {
    response.json(empArr);
});

// About route
app.get("/about", (request, response) => {
    response.status(401).send("Data not found");
});

// Serve login page
app.get("/login", (request, response) => {
    var filePath = path.join(__dirname, "public", "login.html");
    response.sendFile(filePath); // default status code -- 200
});

// Login endpoint
app.post("/api/login", userController.checkUser); // Use the checkUser function from userController

// Registration endpoint
app.post("/api/register", userController.addUser); // Use the addUser function from userController

// Listen on the specified port
app.listen(PORT, (err) => {
    if (!err) {
        console.log("Server is running at PORT :" + PORT);
    }
});
