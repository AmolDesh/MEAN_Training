var { validateUser, registerUser } = require("../model/userModel");

async function checkUser(request, response) {
    var userObj = request.body;
    console.log("checkUser UserController:", userObj);
    try {
        var result = await validateUser(userObj);
        if (result) {
            response.json({ status: true, message: "User login successful" });
        } else {
            response.status(401).json({ status: false, message: "User login failed" });
        }
    } catch (err) {
        response.status(500).json({ status: false, message: err.message });
    }
}

async function addUser(request, response) {
    var userObj = request.body;
    console.log("addUser UserController:", userObj);
    try {
        var result = await registerUser(userObj);
        response.status(201).json(result); // Set status to 201 for created
    } catch (err) {
        response.status(500).json({ status: false, message: err.message });
    }
}

// Export the functions with clear names
module.exports = { addUser, checkUser };
