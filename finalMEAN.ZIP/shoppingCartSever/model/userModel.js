const { MongoClient } = require("mongodb");
const Products = require("./Products");

const uri = "mongodb://127.0.0.1:27017";

const client = new MongoClient(uri);
var db;
async function connectDB() {
  if (!db) { // Check if the database is already connected
    try {
        await client.connect();
        console.log("Connected to MongoDB server");
        db = client.db("shoppingCartDb");
    } catch (err) {
        console.error("Error connecting to MongoDB:", err);
        throw err; // Rethrow the error for handling in the calling function
    }
}
return db; // Return the connected database
}

async function registerUser(userObj) {
    try {
        
        // Validate userObj
        if (!userObj || !userObj.emailId || !userObj.password) {
          throw new Error("User object is incomplete. Required fields: emailId, password.");
        }
        var db = await connectDB();
        const collection = db.collection("users");
        var result = await collection.insertOne(userObj);
        console.log("Result from userModel",result);
        return { status: true, data: `User details inserted with inserted Id : ${result.insertedId}` };

    }

    catch (err) {
        console.error("Error from userModel",err);
        throw err;
    }
}

async function validateUser(userObj) {
    try {
        var db = await connectDB();
        const collection = db.collection("users");
        var result = await collection.findOne({ emailId: userObj.emailId, password: userObj.password });
        // if (result) {
        //     return { status: true, data: `User login successful` };
        // }
        // else {
        //     return { status: false, data: `User login failed` };
        // }
        return result;


    }

    catch (err) {
        console.error("Error from userModel:", err);
        throw err;
    }

}

async function disconnectDB() {
  await client.close();
  console.log("Disconnected from MongoDB server");
}

module.exports = { registerUser, validateUser, disconnectDB };