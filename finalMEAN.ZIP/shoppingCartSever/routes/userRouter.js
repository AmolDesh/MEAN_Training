var express = require('express');
var { checkUser, addUser } = require("../controller/userController")

var usersRouter = express.Router();

usersRouter.post("/register", addUser); // Correctly set up the registration endpoint
usersRouter.post("/login", checkUser); // Ensure this is a POST request for login

module.exports = usersRouter;
