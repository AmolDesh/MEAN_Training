import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { validatePasswordPattern } from '../ValidatorFunctions/validatePasswordPattern';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-register-model',
  standalone: false,
  templateUrl: './register-model.component.html',
  styleUrls: ['./register-model.component.css']
})
export class RegisterModelComponent {
  emailId: FormControl;
  password: FormControl;
  confirmPassword: FormControl;
  phoneNumber: FormControl;
  registerModelFormGroup: FormGroup;

  constructor(private router: Router) {
    this.emailId = new FormControl("", [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")]);
    this.password = new FormControl("", [Validators.required, Validators.minLength(8), validatePasswordPattern()]);
    this.confirmPassword = new FormControl("", [Validators.required]);
    this.phoneNumber = new FormControl("", [Validators.required, Validators.pattern("^[0-9]{10}$")]); // Assuming a 10-digit phone number

    this.registerModelFormGroup = new FormGroup({
      emailId: this.emailId,
      password: this.password,
      confirmPassword: this.confirmPassword,
      phoneNumber: this.phoneNumber
    }, this.passwordMatchValidator); // Pass the validator directly
  }

  passwordMatchValidator(form: AbstractControl): ValidationErrors | null {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { mismatch: true };
  }
  onSubmit(): void {
    if (this.registerModelFormGroup.valid) {
      console.log('Registration Successful!', this.registerModelFormGroup.value);
      // Handle registration logic here
      // After successful registration, navigate to the login page
      this.router.navigate(['/login']);
    } else {
      console.log('Form is invalid');
    }
  }
}
