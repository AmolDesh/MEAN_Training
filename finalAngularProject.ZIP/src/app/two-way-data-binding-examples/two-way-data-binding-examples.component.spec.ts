import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwoWayDataBindingExamplesComponent } from './two-way-data-binding-examples.component';

describe('TwoWayDataBindingExamplesComponent', () => {
  let component: TwoWayDataBindingExamplesComponent;
  let fixture: ComponentFixture<TwoWayDataBindingExamplesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TwoWayDataBindingExamplesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TwoWayDataBindingExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
