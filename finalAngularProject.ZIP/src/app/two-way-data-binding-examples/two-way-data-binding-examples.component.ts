import { Component } from '@angular/core';

@Component({
  selector: 'app-two-way-data-binding-examples',
  standalone: false,
  templateUrl: './two-way-data-binding-examples.component.html',
  styleUrl: './two-way-data-binding-examples.component.css'
})
export class TwoWayDataBindingExamplesComponent {
  countryName: string;
  personName: string;
  fieldNameArr: string[];
  fieldName: string;
  constructor() {
    this.countryName = "India";
    this.personName = "sara";
    this.fieldNameArr = ["productId", "productName", "price", "quantity", "description"];
    this.fieldName = this.fieldNameArr[1];
  }
  inputEventHandler(event: any) {
    console.log("Value type ", event.target.value);
    this.countryName = event.target.value;
  }
}
