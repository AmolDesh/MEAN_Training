import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-net-banking',
  standalone: false,
  templateUrl: './payment-by-net-banking.component.html',
  styleUrl: './payment-by-net-banking.component.css'
})
export class PaymentByNetBankingComponent {

}
