import { Directive } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, ValidationErrors, Validator } from '@angular/forms';
import { validatePasswordPattern } from './ValidatorFunctions/validatePasswordPattern';

@Directive({
  selector: '[appCheckPasswordPattern]',
  standalone: false,
  providers: [
    { provide: NG_VALIDATORS, useExisting: CheckPasswordPatternDirective, multi: true }
  ]
})
export class CheckPasswordPatternDirective implements Validator{

  constructor() { }
  validate(control: AbstractControl): ValidationErrors | null {
    console.log(control);
    return validatePasswordPattern()(control);
  }
}
