export class Products{
    productId:number;
    productName:string;
    imageUrl:string;
    description:string;
    price:number;
    quantity:number;
    constructor(productId:number,
                productName:string,
                imageUrl:string,
                description:string,
                price:number,
                quantity:number) {
        this.productId=productId;
        this.productName=productName;
        this.description=description;
        this.imageUrl=imageUrl;
        this.price=price;
        this.quantity=quantity;
    }
}