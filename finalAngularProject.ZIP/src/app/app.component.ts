import { Component,ViewEncapsulation } from '@angular/core';
//import { RouterOutlet } from '@angular/router';

@Component({
  standalone: false,
  selector: 'app-root',
  //imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  //encapsulation:ViewEncapsulation.ShadowDom,
  encapsulation:ViewEncapsulation.Emulated,
})
export class AppComponent {
  title = 'myFirstProject';
  companyName:string;
  fruits:string[];
  isMember:boolean;
  ctr:number;
  empObj:any;
  bday:Date;
  imgURL: string; // Declare imgURL property
  constructor()
  {
    this.companyName="Marsh";
    this.fruits=["apple,guava,pineapple,banana"]
    this.isMember=true;
    this.ctr=10;
    this.empObj={empId:101,empName:"Amol",salary:3801};
    this.bday=new Date(1991,0,4);
    //this.bday = new Date("1991-2-04"); // Corrected date format
    //this.imgURL = 'https://example.com/path/to/your/image.jpg'; // Initialize with your image URL
    this.imgURL = "Screenshot (10).png"
  }

}
