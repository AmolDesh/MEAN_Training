/* import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-examples',
  standalone:false,
  templateUrl: './directive-examples.component.html',
  styleUrl: './directive-examples.component.css'
})
export class DirectiveExamplesComponent {

} */

import { Component } from '@angular/core';

@Component({
  selector: 'app-directive-examples',
  standalone:false,
  templateUrl: './directive-examples.component.html',
  styleUrls: ['./directive-examples.component.css']
})
export class DirectiveExamplesComponent {
  myFavColor: string;
  myBorder: string;
  constructor() {
    this.myFavColor = "pink";
    this.myBorder = "5px double blue";
  }
}
