import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-card',
  standalone: false,
  templateUrl: './payment-by-card.component.html',
  styleUrls: ['./payment-by-card.component.css']
})
export class PaymentByCardComponent {
cardNumber: any;
cardHolderName: any;
expiryDate: any;
cvv: any;
  
  saveCardDetails() {
    // Logic to save card details
    alert("Card details saved successfully!");
  }

  proceedToPayment() {
    // Logic to proceed to payment
    alert("Proceeding to payment...");
  }
}
