import { Component } from '@angular/core';
import { Form, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register-template',
  standalone: false,
  templateUrl: './register-template.component.html',
  styleUrl: './register-template.component.css'
})
export class RegisterTemplateComponent {
  submitEventHandler(registerFormValues: any) {
    console.log(registerFormValues);
    // send this data to the server via POST request

}
}