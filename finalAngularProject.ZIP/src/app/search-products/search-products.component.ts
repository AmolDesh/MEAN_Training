import { Component } from '@angular/core';
import { Products } from '../model/Products';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-search-products',
  standalone: false,
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
  productsArr: Products[]= [];
  searchText: string;
  fieldName: string;
  fieldNameArr: string[];
  selectedProduct: Products | null;
  constructor(private productManagementService: ProductManagementService) {
    this.selectedProduct = null;
    this.fieldName = "";
    this.searchText = "";
    this.fieldNameArr = ["productId", "productName", "price", "quantity", "description"];
  }
  ngOnInit(): void {
    // Fetch the latest product data from the service
    this.productsArr = this.productManagementService.getAllProductsItems();
  }
  searchEventHandler(text: string, fieldName: string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }
  editEventHandler(selectedProduct: Products) {
    this.selectedProduct = selectedProduct;
  }
}
