/* import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

} */
import { Component } from '@angular/core';
import { Cart } from '../model/Cart';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  showCart: boolean;
  //cartItems: Cart[] = []; // Array to hold cart items
  constructor() {
    this.showCart = false;
  }
 
  showElement(componentName: string) {
    if (componentName == 'cart') {
      this.showCart = true;
    }
    else {
      this.showCart = false;
 
    }
  }
/*   addToCartEvent(cartItem: Cart) {
    console.log('Item added to cart:', cartItem);
    this.cartItems.push(cartItem); // Add item to cart
  } */
}