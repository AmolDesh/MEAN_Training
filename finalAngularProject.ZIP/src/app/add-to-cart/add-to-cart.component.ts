/* import { Component, Input } from '@angular/core';
import { Products } from '../product-display/product-display.component';

@Component({
  selector: 'app-add-to-cart',
  standalone: false,
  templateUrl: './add-to-cart.component.html',
  styleUrl: './add-to-cart.component.css'
})

  export class AddToCartComponent {
    @Input() companyName: string; // Normal field to AddToCart component.
    @Input() product: Products | null; // Product can be null
    quantity: number = 1; // Default quantity

    constructor() {
        this.companyName = "";
        this.product = null; // Changed from 'selProduct' to 'product'
    }
    ngOnChanges() {
      // Reset quantity to 1 when the product changes
      if (this.product) {
        this.quantity = 1; // Reset quantity to 1 for the new product
      }
    }
    addToCart(product: Products | null) {
      if (product) { // Check if product is not null
        if (this.quantity > 0 && this.quantity <= product.availableQuantity) {
          alert(`Added ${this.quantity} of ${product.name} to cart!`);
            // Implement logic to add the product to the cart
        } else {
          alert(`Please select a quantity between 1 and ${product.availableQuantity}.`);
        }
      }else {
        alert('No product selected.');
      }
    }

    incrementQuantity() {
      if (this.product && this.quantity < this.product.availableQuantity) {
          this.quantity++;
      } else {
          alert(`Cannot select more than available quantity (${this.product?.availableQuantity}).`);
      }
    }

    decrementQuantity() {
      if (this.product && this.quantity > 1) {
        this.quantity--;
      } else {
          alert('Quantity cannot be less than 1.');
      }
    }
  } */
    import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, OnDestroy } from '@angular/core';
    import { Products } from '../model/Products';
    import { Cart } from '../model/Cart';
    import { CartManagementService } from '../cart-management.service';
 
    @Component({
      selector: 'app-add-to-cart',
      standalone: false,
      templateUrl: './add-to-cart.component.html',
      styleUrl: './add-to-cart.component.css',
    })
    export class AddToCartComponent implements OnInit, OnChanges, OnDestroy{
      cartObj: Cart | null;
      tempVar: string = "hello";// not a best practice; no default values if we dont initialise
      quantitySelected:number;
    
      @Input() companyName: string; // Normal field to AddToCart component.
      // @Input decorator is going to make it get data from parent
      @Input("selProduct") product: Products | null;
      @Output() sendDataFromAddToCartToPD: EventEmitter<Cart| null>;
      @Output() sendCancelEventFromAddToCartToPD: EventEmitter<void>;
     
      constructor(private cartManagementService: CartManagementService) {
        console.log("Constructor of Add To cart called");
        this.companyName = '';
        this.product = null;
        this.cartObj = null;
        this.quantitySelected = 1;
        this.sendDataFromAddToCartToPD = new EventEmitter<Cart|null>();
        this.sendCancelEventFromAddToCartToPD = new EventEmitter<void>();

      }
      ngOnDestroy(): void {
        if (this.cartObj) {
          alert("Items added to the cart with productId " + this.product?.productId);
        }
        else {
          alert("Sorry to see u go !!!!");
        }
      }
      ngOnChanges(changes: SimpleChanges): void {
        console.log("OnChanges in Add to cart called");
        console.log("Changes", changes);
        if(changes['product'] && changes['product'].previousValue && changes['product'].currentValue.productId !== changes['product'].previousValue.productId)
          this.quantitySelected = 1;
        console.log("Selected Product: ", this.product);// mounting -- ud; product clicked
        // constructor -- product -- null;
        // ngOnInit -- product -- data from the parent
        // when is the data from the parent assigned to the input decorators -- after ngOnChanges; before 
        // Answer : -- data assignment -- ngOnChanges 
       
      }
     
      ngOnInit(): void {
        console.log("OnInit in Add to cart called");
        console.log("Selected Product: ", this.product);
       
      }
     
     
      modifyQuantity(op:string) {
       
        if(op=='dec'){
          if(this.quantitySelected > 0) {
     
            this.quantitySelected--;
          }
        }
          else {
            if(this.product && (this.quantitySelected<this.product.quantity)) {
              this.quantitySelected++;
            }
          }
      }
      confirmEventHandler() {
        this.cartObj = this.product ? new Cart(this.product.productId, this.product.productName, this.product.imageUrl, this.product.description, this.product.price, this.product.quantity, this.quantitySelected) : null;
        if (this.cartObj) {
          // trigger the event or emit the event
          this.sendDataFromAddToCartToPD.emit(this.cartObj);
    
          this.cartManagementService.addCartItem(this.cartObj);
        }
     
      }
      cancelEventHandler() {
         // trigger an event 
        this.sendCancelEventFromAddToCartToPD.emit();
      }
    }