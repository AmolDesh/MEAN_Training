import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductManagementService } from '../product-management.service';
import { Products } from '../model/Products';

@Component({
  selector: 'app-product-details',
  standalone: false,
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  selectedProductId: number;
  selectedProduct: Products | null;

  constructor(private route: ActivatedRoute, private productManagementService: ProductManagementService) {
    this.selectedProductId = -1;
    this.selectedProduct = null;
  }

  ngOnInit() {
    // Get the productId from the route parameters
    if (this.route.snapshot.paramMap.has("productId")) {
      this.selectedProductId = parseInt(this.route.snapshot.paramMap.get("productId") ?? "-1");
      // Fetch the product details using the product ID
      this.selectedProduct = this.productManagementService.getAllProductsItems().find(product => product.productId === this.selectedProductId) || null;
    } else {
      this.selectedProductId = -1;
    }
  }
}
