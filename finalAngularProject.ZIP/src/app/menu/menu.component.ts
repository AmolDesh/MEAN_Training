import { Component } from '@angular/core';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-menu',
  standalone: false,
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {
  constructor(private router: Router) {}

  logout() {
    // Clear user session or token here
    localStorage.removeItem('user'); // Example: remove user data from local storage
    // Redirect to login page
    this.router.navigate(['/login']);
  }

}
