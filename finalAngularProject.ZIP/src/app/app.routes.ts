import { Routes } from '@angular/router';
import { RegisterTemplateComponent } from './register-template/register-template.component';
import { HomeComponent } from './home/home.component';
import { RegisterModelComponent } from './register-model/register-model.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { TwoWayDataBindingExamplesComponent } from './two-way-data-binding-examples/two-way-data-binding-examples.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByUPIComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { LoginComponent } from './login/login.component';
import { CartComponent } from './cart/cart.component';

export const routes: Routes = [
  // { path: "login", component: LoginComponent },
  { path: "login", component: LoginComponent },
  { path: "registerReactive", component: RegisterModelComponent },
  { path: "products", component: HomeComponent },
  { path: "cart", component: CartComponent },
  {path:"productDetails/:productId",component:ProductDetailsComponent},
  { path: "registerTemplate", component: RegisterTemplateComponent },
  { path: "searchProducts", component: SearchProductsComponent },
  { path: "twowayBinding", component: TwoWayDataBindingExamplesComponent },
  { path: "directiveExamples", component: DirectiveExamplesComponent },
  { 
    path: "payments", 
    component: PaymentsComponent,
    children: [
      { path: "card", component: PaymentByCardComponent },
      { path: "wallet", component: PaymentByWalletComponent },
      { path: "upi", component: PaymentByUPIComponent },
      { path: "netbanking", component: PaymentByNetBankingComponent },
      { path: "", redirectTo: "card", pathMatch: "full" } // Ensure this line is correctly formatted
    ]  
  },
  { path: "", redirectTo: "login", pathMatch: 'full' },
  { path: "**", component: PageNotFoundComponent }
];