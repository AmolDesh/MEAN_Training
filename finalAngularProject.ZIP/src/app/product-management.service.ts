import { Injectable } from '@angular/core';
import { Products } from './model/Products';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor() { 
    this.productsArr = [
      new Products(101, "Product 1", "Prd1.png", "Product 1 Description", 112345, 5),
      new Products(102, "Product 2", "Prd2.jpg", "Product 2 Description", 11345, 10),
      new Products(103, "Product 3", "Prd3.jpg", "Product 3 Description", 56782, 15),
      new Products(104, "Product 4", "Prd4.png", "Product 4 Description", 151345, 20),
      new Products(105, "Product 5", "Prd5.jpg", "Product 5 Description", 12345, 25),
    ];
  }
  addProductsItem(ProductsObj: Products) {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr)
  }
  getAllProductsItems() {
    return this.productsArr;
  }
  deleteProductsItem(productId: number) {
    var pos = this.productsArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.productsArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  }
}
