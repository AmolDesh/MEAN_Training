import { Component, Input } from '@angular/core';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {
  cartArr: Cart[];
  constructor(private router: Router, private cms: CartManagementService) {
    this.cartArr = cms.getAllCartItems();
  }

  getTotalAmount(): number {
    return this.cartArr.reduce((total, item) => total + (item.price * item.quantitySelected), 0);
  }
  proceedToPaymentEventHandler() {
    // navigate to /payments
    this.router.navigate(['/payments']);

  }
}

